
 extern SV_STRING getenv_0(/* INPUT */const char* env_name);
